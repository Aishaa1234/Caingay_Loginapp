 package com.example.loginactivity


 import android.os.Bundle
 import android.widget.Toast
 import androidx.activity.ComponentActivity
 import androidx.activity.compose.setContent
 import androidx.activity.enableEdgeToEdge
 import androidx.compose.foundation.layout.*
 import androidx.compose.material3.*
 import androidx.compose.runtime.*
 import androidx.compose.ui.Modifier
 import androidx.compose.ui.text.input.PasswordVisualTransformation
 import androidx.compose.ui.unit.dp
 import com.example.loginactivity.ui.theme.LoginActivityTheme

 class MainActivity : ComponentActivity() {
     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
         enableEdgeToEdge()
         setContent {
             LoginActivityTheme {
                 Surface(modifier = Modifier.fillMaxSize()) {
                     LoginScreen { message ->
                         Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                     }
                 }
             }
         }
     }
 }

 @Composable
 fun LoginScreen(onLoginResult: (String) -> Unit) {
     var username by remember { mutableStateOf("") }
     var password by remember { mutableStateOf("") }
     var isLoggedIn by remember { mutableStateOf(false) }

     val correctUsername = "karla"
     val correctPassword = "bisaya123"

     Column(
         modifier = Modifier
             .fillMaxSize()
             .padding(24.dp),
         verticalArrangement = Arrangement.Center
     ) {
         if (isLoggedIn) {
             Text(
                 text = "Welcome, $username!",
                 style = MaterialTheme.typography.headlineMedium,
                 modifier = Modifier.padding(bottom = 16.dp)
             )


             Button(onClick = {
                 isLoggedIn = false
                 username = ""
                 password = ""
             }, modifier = Modifier.fillMaxWidth()) {
                 Text("LOGOUT")
             }
         } else {
             Text(
                 text = "Please enter your username and password below to login:",
                 style = MaterialTheme.typography.bodyLarge,
                 modifier = Modifier.padding(bottom = 24.dp)
             )

             OutlinedTextField(
                 value = username,
                 onValueChange = { newUsername -> username = newUsername },
                 label = { Text("Enter your username") },
                 singleLine = true,
                 modifier = Modifier
                     .fillMaxWidth()
                     .padding(bottom = 16.dp)
             )

             OutlinedTextField(
                 value = password,
                 onValueChange = { newPassword -> password = newPassword },
                 label = { Text("Enter your password") },
                 singleLine = true,
                 visualTransformation = PasswordVisualTransformation(),
                 modifier = Modifier
                     .fillMaxWidth()
                     .padding(bottom = 24.dp)
             )

             Button(
                 onClick = {
                     if (username.trim() == correctUsername && password.trim() == correctPassword) {
                         isLoggedIn = true
                         onLoginResult("Login successful")
                     } else {
                         onLoginResult("Invalid username or password")
                         password = ""
                     }

                 },
                 modifier = Modifier.fillMaxWidth()
             ) {
                 Text("LOGIN")
             }
         }
     }
 }
